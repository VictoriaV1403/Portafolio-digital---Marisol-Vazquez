
import javax.faces.bean.ManagedBean;

@ManagedBean
public class PerfilBean {
    private Perfil perfil;

    public PerfilBean() {
        perfil = new Perfil("Marisol Vazquez", 
                            "Ingeniería en Tecnologias de la información y comunicaciones", 
                            "foto_perfil.jpg", 
                            "Java", 
                            "MySQL", 
                            "Proyecto A", 
                            8.8);
    }

    public Perfil getPerfil() {
        return perfil;
    }

    public void setPerfil(Perfil perfil) {
        this.perfil = perfil;
    }
}



