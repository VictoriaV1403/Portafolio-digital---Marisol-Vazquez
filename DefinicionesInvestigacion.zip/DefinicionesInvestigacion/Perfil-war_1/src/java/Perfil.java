
public class Perfil {
    private String nombre;
    private String carrera;
    private String foto;
    private String lenguajesProgramacion;
    private String baseDatos;
    private String proyectosRealizados;
    private double promedio;

    public Perfil(String nombre, String carrera, String foto, String lenguajesProgramacion, 
                  String baseDatos, String proyectosRealizados, double promedio) {
        this.nombre = nombre;
        this.carrera = carrera;
        this.foto = foto;
        this.lenguajesProgramacion = lenguajesProgramacion;
        this.baseDatos = baseDatos;
        this.proyectosRealizados = proyectosRealizados;
        this.promedio = promedio;
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getLenguajesProgramacion() {
        return lenguajesProgramacion;
    }

    public void setLenguajesProgramacion(String lenguajesProgramacion) {
        this.lenguajesProgramacion = lenguajesProgramacion;
    }

    public String getBaseDatos() {
        return baseDatos;
    }

    public void setBaseDatos(String baseDatos) {
        this.baseDatos = baseDatos;
    }

    public String getProyectosRealizados() {
        return proyectosRealizados;
    }

    public void setProyectosRealizados(String proyectosRealizados) {
        this.proyectosRealizados = proyectosRealizados;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }
}
