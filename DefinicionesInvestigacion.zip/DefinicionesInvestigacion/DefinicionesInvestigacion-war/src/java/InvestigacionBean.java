
import javax.faces.bean.ManagedBean;

@ManagedBean
public class InvestigacionBean {
    private investigacion investigacion;

    public InvestigacionBean() {
        investigacion = new investigacion("Métodos de Investigación", 
                                          "Una descripción de los métodos de investigación...", 
                                          "Referencia: Libro de Métodos", 
                                          "imagen_investigacion.jpg");
    }

    public investigacion getInvestigacion() {
        return investigacion;
    }

    public void setInvestigacion(investigacion investigacion) {
        this.investigacion = investigacion;
    }
}

